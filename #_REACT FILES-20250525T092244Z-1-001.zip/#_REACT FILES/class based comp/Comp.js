import React from 'react';
import './App.css';
import ClassComp from './ClassComp';

function Comp() {
  return (
    <div>
      <ClassComp/>
    </div>
  );
}

export default Comp;