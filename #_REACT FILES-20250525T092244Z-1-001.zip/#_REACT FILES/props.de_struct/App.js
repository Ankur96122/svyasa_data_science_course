import './App.css'
import De_com from './De_com';

function App() {
  let name = "Don't talk about the club";
  let student = {
    name: "parker",
    age: 25,
    city: "toronto",
    country: "canada",
  }

   return (
    <div className="App">
     <h2>The first rule of the club is {name}</h2>
     <De_com myStudent={student} />
    </div>
  );}
export default App;
