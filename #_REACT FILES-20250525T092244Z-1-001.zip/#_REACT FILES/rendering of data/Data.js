import React from 'react';

const fruits = [
    { id: 1, name: 'Apple' },
    { id: 2, name: 'Banana' },
    { id: 3, name: 'Cherry' },
  ];
const Data = () => {
    return (
        <div>
      <h1> fruits </h1>
      <ol>
        {fruits.map((fruit) => (
          <li key={fruit.id}>{fruit.name}</li>
        ))}
      </ol>
      </div>
    );
  };

  export default Data;