import React, { useState, useEffect } from 'react';
import Axios from 'axios';


function AxiosReact() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  useEffect(() => {
    Axios.get('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd')
      .then(res => {
        setData(res.data); // Directly access the parsed data here
      })
      .catch(err => {
        setError(err.message);
      });
  }, []);
  return (
    <div>
      {data && <div>{JSON.stringify(data)}</div>}
      {error && <div>Error: {error}</div>}
    </div>
  );
}
export default AxiosReact;