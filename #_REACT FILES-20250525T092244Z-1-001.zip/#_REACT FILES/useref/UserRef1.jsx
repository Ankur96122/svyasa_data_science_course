import React, { useRef,useState } from 'react'

const UserRef1 = () => {

    let x =useRef(10);
    let [y,setY] = useState(0);

  return (
    <div>

        <h1>intial x value : {x.current}</h1>
        <h1> y value rendering : {y}</h1> 
        
        
        <button onClick={() => {
            x.current = x.current + 1;
            console.log(x.current);
        }}>increment of X </button> <br/> <br/>

        <button onClick={() => {
            setY(y+1);
        }}>increment of Y</button>
    
    </div>
  )
}

export default UserRef1
