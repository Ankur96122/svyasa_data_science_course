import React from 'react'
import { useRef } from 'react'

function UseRef() {

    let element = useRef(null)
  return (
    <div>
        <h1 ref={element} >useRef</h1>
        <p>useRef is a hook that allows you to create a mutable object which holds a .current property. This object will persist for the full lifetime of the component.useRef is useful for accessing a DOM element directly, or for keeping a mutable value around similar to how you would use instance fields in classes.useRef does not cause re-renders when the object it holds changes. This is different from useState, which does cause re-renders when the state changes.</p>

<button onClick={() => {
    console.log(element)
    console.log(element.current)
    element.current.innerHTML = 'element changed'
    }}>Change h1 element</button>
 
    </div>
  )
}

export default UseRef
