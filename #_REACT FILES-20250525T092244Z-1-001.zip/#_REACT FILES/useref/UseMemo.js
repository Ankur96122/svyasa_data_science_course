import React, { useState, useMemo } from 'react';

const UseMemo = () => {
  const [a, setA] = useState(10);
  const [b, setB] = useState(20);

  // Memoize the sum of a and b
  const sum = useMemo(() => {
    console.log('sum is calculated', a,b, 'a+b =', a+b);
    return a + b;
  }, [a, b]); // Recalculate only when 'a' or 'b' changes

  return (
    <div>
      <h1>useMemo</h1>
      <p>useMemo is a hook that allows you to memoize expensive calculations so that they are only recomputed when their dependencies change. This can help improve performance in your application by avoiding unnecessary re-renders and recalculations.</p>

      <button onClick={() => setA(a + 1)}>Increment A</button>
      <button onClick={() => setA(a - 1)}>Decrement A</button> <br /> <br />

      <button onClick={() => setB(b + 1)}>Increment B</button>
      <button onClick={() => setB(b - 1)}>Decrement B</button> <br /> <br />

      <h1>Sum of A and B is : {sum}</h1>
    </div>
  );
};

export default UseMemo;