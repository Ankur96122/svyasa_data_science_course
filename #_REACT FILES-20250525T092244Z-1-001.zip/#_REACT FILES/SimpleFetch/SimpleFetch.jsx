import React, { useState, useEffect } from 'react';

function SimpleFetch() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);


  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/todos/1')
      .then(res => res.json())
      .then(json => setData(json))
      .catch(err => setError(err.message));
  }, []);

  return (
    <div>
      {data && <div>{JSON.stringify(data)}</div>}
      {error && <div>Error: {error}</div>}
    </div>
  );
}

export default SimpleFetch;
