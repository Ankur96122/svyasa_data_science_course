// App.js
import './App.css';
import { Routes, Route, BrowserRouter, Link } from 'react-router-dom';
import About from './Route_src/About';
import Home from './Route_src/Home';
import Contact from './Route_src/Contact';
import React from 'react';

function Header() {
  return (
    <div>
      <ul>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/about">About</Link></li>
        <li><Link to="/contact">Contact</Link></li>
      </ul>
    </div>
  );
}

function AppRoutes() { // Renamed from Route to AppRoutes
  return (
    <BrowserRouter>
      <Header /> {/* Include the Header component */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </BrowserRouter>
  );
}

export default AppRoutes; // Export the AppRoutes component