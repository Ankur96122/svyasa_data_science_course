import React from 'react'

function Contact() {
  return (
    <div>
        <h1>this is Contact</h1>
        <p>Contact page content goes here.</p>
      
    </div>
  )
}

export default Contact
