import React from 'react'

function Home() {
  return (
    <div>
        <h1>this is Home</h1>
        <p>Home page content goes here.</p>
      
    </div>
  )
}

export default Home
