import React from 'react'

function About() {
  return (
    <div>
      <h1>this is About</h1>
      <p>About page content goes here.</p>
    </div>
  )
}

export default About
