import { useState } from "react";

function Signupform() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  return (
    <>
      <div>
        <h2>Login Form</h2>

        <div>
          <label>Email</label>
          <input type='email'
            className='form-control'
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="mt-3">
          <label>Password</label>
          <input type='password'
            className='form-control'
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <div className="mt-3">
          <button onClick={() => {
              console.log("email:", email);
              console.log("password:", password);
            }}>Login</button>
        </div>
      </div>
    </>
  );
}

export default Signupform;