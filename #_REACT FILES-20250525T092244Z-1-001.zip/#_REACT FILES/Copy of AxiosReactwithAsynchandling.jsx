import React, { useState, useEffect } from "react";
import Axios from "axios";

function AxiosReact() {
  const [data, setData] = useState(null); 
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await Axios.get(
          "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd"
        );
        setData(response.data);
      } catch (err) {
        setError(err.message);
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      <h2> Bitcoin Price </h2>
      {data && <div>USD: ${data.bitcoin.usd}</div>}
      <h1> Waiting </h1>
      {error && <div style={{ color: "red" }}>Error: {error}</div>}
    </div>
  );
}

export default AxiosReact;


