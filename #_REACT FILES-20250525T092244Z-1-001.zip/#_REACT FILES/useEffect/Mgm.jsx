import React, { useState, useEffect } from 'react';
const StateMgm = () => {
    const [city, setCity] = useState("Hyderabad");

    // useEffect to change the city based on a condition
    useEffect(() => {
        if (city === "Hyderabad") {
            setCity("Haryana");
        }else{
            setCity("goa");
        }
    }, []); // Dependency array includes city

    return (
        <div>
            <h1>I live in {city}</h1>
        </div>
    );
}

export default StateMgm;