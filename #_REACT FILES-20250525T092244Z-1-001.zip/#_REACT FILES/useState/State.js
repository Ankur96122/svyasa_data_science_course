import React from 'react'
import { useState } from 'react'
import './App.css'

function State() {
    const [name, setName] =useState("parker")
    
    const style = {
        color: "red",
        textAlign: "center",
        border : "2px solid black",
    }   
     return (
    
    <div>
      <h1 style={style}> My name is {name} </h1>
      <button onClick={() => setName(" peter parker 🕷️")}>change name</button>
    </div>
  )
}

export default State
